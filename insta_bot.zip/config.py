tg_token="7386189930:AAGcGdwxgS-nHKtywNAsAnVTcqDTJ0X36Rk"

db_host = "127.0.0.1"
db_port = "5432"
db_username = "main_user"
db_password = "Qwerty123"
db_name = "inst_parse_bot"

star_prices = {
    "7d":{
        "star_price":85,
        "rub_price":99,
        "usd_price":1.19,
        "days":7
    },
    "1m":{
        "star_price":274,
        "rub_price":319,
        "usd_price":3.89,
        "days":30
    },
    "3m":{
        "star_price":722,
        "rub_price":839,
        "usd_price":9.99,
        "days":30*3
    },
    "6m":{
        "star_price":1264,
        "rub_price":1469,
        "usd_price":17.19,
        "days":30*6
    },
    "1y":{
        "star_price":2315,
        "rub_price":2689,
        "usd_price":31.49,
        "days":365
    },
    "forever":{
        "star_price":3607,
        "rub_price":4189,
        "usd_price":48.99,
        "days":9999
    },
}

cryptomus_merchant_id = "5be61c33-28cb-4e99-8f9e-954b7d74bdfb"
yookassa_key = "abcd"